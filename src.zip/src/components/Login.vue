
<template>
  <div> login page</div>
</template>

<script>
    export default {
         data(){
              return {

              }
         }
    }
</script>