<template>
	<div>
		HOME
	</div>
</template>

<script>
import Header from '@/components/Header';
import Footer from '@/components/Footer';
export default {
         data(){
			return {
				keyword:'',
				users:[
						{id:1,name:'BTC'},
						{id:2,name:'ETH'},
						{id:3,name:'QTUM'},
						{id:4,name:'NEO'},
						{id:5,name:'BCC'},
						{id:6,name:'EOS'}
					]
			}
		},
		methods:{
			clickHandler(){
				this.users[0]['name'] = 'sss'
				console.log('33')
			}
		},
		components:{Header,Footer},
		created:()=>{
			console.log('created');
			
		}
	}
</script>

<style scoped>
	.list-item {
		width:20%;
		padding-top:10px;
		padding-bottom:10px;
		background:#FFF;
		list-style:none;
		border-bottom:1px solid #EEE;
		text-align:left;
		padding-left:8px

	}
	.list-item:hover {
		background:gray;
		color:#FFF;
		opacity:0.3;
	}
</style>