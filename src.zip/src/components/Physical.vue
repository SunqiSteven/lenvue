<template>
	<div>
		physical
	</div>
</template>

<script>
	export default {
		data(){
			return {

			}
		}
	}
</script>