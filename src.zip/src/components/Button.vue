<template>
	<button v-on:click="clickHandler()">{{text}}</button>
</template>
<script>

	export default {
		props:['text'],
		data(){
			return {
				
			}
		},
		methods:{
			clickHandler(){
				console.log('22');
				this.$emit('on-click');
			}
		}
	}
</script>