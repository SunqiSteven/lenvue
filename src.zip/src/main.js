// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import {router} from './router'
import Vuex from 'vuex'
Vue.config.productionTip = false
Vue.use(Vuex);
var store = new Vuex.Store({
   state:{
      headerTitle:'体检'
   },
   mutations:{
     changeHeaderTitle(state,title){
       console.log(state);
       console.log(title)
      state.headerTitle = title;
     }
   }
})
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App }
})
